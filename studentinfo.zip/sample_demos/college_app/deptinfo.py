


class Employee:

    def __init__(self): # constructor
        pass


    def employee_apprisal(self):        # instance method       --> HR OBJECT K LIYE SPECIFIC
        pass

    @staticmethod           # COMMON --> ACROSS ALL OBJECTS
    def gathering():
        pass

    @classmethod                                # USI CLASS K OBJECTS
    def new_employee_registrtion(cls,*args):
        pass



class Student:

    def __init__(self,stid,stnm,stage):
        self.studId = stid
        self.studName = stnm
        self.studAge = stage


    @staticmethod
    def document_verication(stud):
        pass

    @classmethod
    def admit_to_dept(cls,stid,stnm,stage):     # cls --> Class name k
        return cls(stid,stnm,stage)       #Student(10,"AAA",23)


s1 = Student(10,"AAA",23)
s1 = Student.admit_to_dept(10,"AAA",23)



class Student:

    def __init__(self):
        pass

    def __str__(self):
        pass

    def __repr__(self):
        pass

    @classmethod        # class/object ---> class
    def display_student_information(cls):      # first param is reserved for  classs
        pass

    #instance           # object
    def create_student_instance(self):  #first param is reserved for --> current obj k ref
        pass

    @staticmethod           # class/object ---> class                # no reserved param
    def show_student_information():
        pass





class Dept:

    def __init__(did,self,dnm):
        print('inside init',self)       # memory --> 3 diff memory
        self.deptId = did
        self.deptName = dnm


d1 = Dept(did=101,dnm='Information Tech')
d2 = Dept(did=102,dnm="Computer")
d3 = Dept(did=103,dnm="Electronics")

# we have 3 instances/objects --. d1,d2,d3 --> object ya object ref