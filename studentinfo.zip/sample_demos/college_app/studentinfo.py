

class Student:      # Student --> is a class --> kind structure/template/

    def __init__(x,studid,studnm,studage,studgender,studemail,studadr="Pune"):     # constructor ka bolo --> studadr="Pune" [default]
        x.studId = studid
        x.studName = studnm
        x.studEmail = studemail
        x.studGender = studgender
        x.studAge = studage
        x.studAddress = studadr

s1 = Student(101,"ABCD",20,"Male","abc@gmail.com","Pune")   # positional param
s2 = Student(studid=102,studnm='XXX',studage=23,studgender='Female',studemail="xyz@gmail.com",studadr="Mumbai") # named param

# init/construcotr ---> classkaname()   --> classkaname(params*)

#s1,s2 --. ref variables/object --> Student type k object

#current object ka ref -->

#instance method ka first params --> is reserved for --. ref --> hold --> current object ka/memory ka


#constructor is a special method --> which is used to ini the object fields
