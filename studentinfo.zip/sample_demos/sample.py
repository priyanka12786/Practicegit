

def addition(**kwargs):
    result = kwargs.get('num1') + kwargs.get('num2')
    return result


def multiplication(num1,num2):
    result = num1 * num2
    return result

'''

revise - swagger 

MVC part -->
        CRUD
        

'''