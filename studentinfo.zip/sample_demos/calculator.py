

class Student:

    @classmethod                # class method              # class/object --> class
    def m1(cls):
        pass

    @staticmethod
    def m2():                   #static method              # class/object --> class
        pass

    def m3(self):               # instance method           # object
        pass

num1 = 10            # num1 --> int type ka object
num2 = int(10)       # num2 --> int type ka object

value = list()          # value --> type of list --> object
value.append(10)
value.append(20)

s1 = Student()      # s1 --> object     # s1 -> is an object of type Student class
s2 = Student()      # s2 --> Object     # s2 --> is an object of type student class


# who written this student class --> user defined --    # business type specific types-->
        # developer needs to define..
# list/int/float/complex/set/tuple etc ---> system defined/python defined




class Calculator:

    def addition1(self,num1,num2):
        result = num1 + num2
        return result

    def multiplication1(self,num1,num2):
        result = num1 * num2
        return result