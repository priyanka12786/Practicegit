from sample import addition,multiplication


addition(10,29)
multiplication(190,24)

from calculator import Calculator  #method ko access karne k liye we need class/object

addition1()


values = [10,5204,333]
values.sort()       # method  --> listkaobject.method ko call
sorted(values)      # function  #--> function ko list pass kar


#method write karne k liye mere pass class -->
# us method ko call karene ke liye --> class/object

# function --> class/object  not required --> can be directly called..

# function define --> generic across multiple purpose
# method --> koi specific purpose --> method class --> encasulated