
class Employee:
    companyName = "TCS"             # class variables [outside the method and at class level]

    def __init__(self,eid,enm):     #constructor --> instance kind of
        self.empId = eid        # instance
        self.empName = enm      # instance
        Employee.companyAddress = "Pune"  # class variable
        self.companyAddress = "Pune"      # instance variable

    def m1(self):               #instance method        # object ref
        print('inside m1')


    @classmethod
    def m2(self):       # self ---> cls --> class ka name
        print('inside m2')

    @staticmethod
    def m3():
        print('static method')

    def __str__(self):
        return f'''{self.__dict__}'''

    def __repr__(self):
        return str(self)

e1 = Employee(101,'XXXX')
print(e1)

e2 = Employee(101,'XXXX')
print(e1)


import sys
sys.exit(0)

class Student:

    def __init__(self,id,nm,age,fees):
        self.studId = id
        self.studName = nm
        self.studAge = age
        self.studFees = fees
        #self.companyAddress = 'X'  # instance variable
                            # this method is callback [automatically gets called] whenever
                            # print ref of the object
    def __str__(self):      # this function will be called implicitly whenever you print
        return f'\n {self.__dict__}'                 # the reference of student type of object
                            # return value should be string ==

    def __repr__(self):     # collection of student object/instances --> str-- one by ref
        return str(self)
    @staticmethod                               #static method
    def display_student_info(ref,adr):             # koi param reserved    --> display_student_info()
        #Student.address = adr   # ??
        ref.address = adr

    @classmethod                        #classmethod
    def create_student(cls,id,nm,age,fees):           #Student.create_student()-----> cls Student
        if type(int) and id>0:
            if type(nm) == str and len(nm) >2:
                if type(age)==int and age>10:
                    if (type(fees) == int or type(fees)==float) and fees>10000.0:
                        return cls(id,nm,age,fees)  # this statement will call to init/constructor ko---> return karega -- initlized fields along with object
                    else:
                        print('Invalid Fees')
                else:
                    print('Invalid Age')
            else:
                print('Invalid Name')
        else:
            print('Invalid Id')

                                        #self --> current object ka ref...
    def show_student_infor(self):      #instance method --> self -->  obj ref
        self.studAge = 30

    @staticmethod
    def avgfees(students):      # 1.classmethod ??NO (because we want to pass list of students(objects))   --> 2.instance-NO here we can pass only one object(because we want to pass list of students(objects))-- 3.jab common business part hotafor all students-statics
        totalFees = 0
        for stud in students:
            totalFees = totalFees + stud.studFees
        print('Total Fees : ',totalFees)
        return totalFees/len(students)


                                                      #reason ???
s1 = Student.create_student(1012,'GAAAA',20,228934.4) # class k method k thru
s2 = Student.create_student(1013,'AFAAA',20,218934.4)
s3 = Student.create_student(1041,'AAAAA',20,238934.4)
s4 = Student.create_student(1051,'XAAAA',20,428934.4)
print(s1)
print(s2)
print(s3)
print(s4)       #
print('\n\nPrinting list of students/ students in bulk..')
students = [s1,s2,s3,s4]
print(students)
import sys
sys.exit(0)


print('ID -->',id(s1))   #1586260894576  --> hex to decimal --> id
print('Type -->',type(s1)) # Student
print('Direct Print ',s1)       #memory address --> hex format --> i am not interested in memory--
                #instead muze- - Attributes
print('Dict-->',s1.__dict__)  # print karega --> attributes
print('Dict-->',s2.__dict__)
print('Dict-->',s3.__dict__)

import sys
sys.exit(0)
print('S1',s1)
print('S2',s2)
print('S3',s3)
print('S4',s4)

print('*'*400)

s3.show_student_infor()     # this will change --> s3 ka age..
print(s3)
s2.show_student_infor()     # this will change --> s2 ka age
print(s2)
print('-'*40)


students = [s1,s2,s3,s4]
ans = Student.avgfees(students)
print('AvgFees : ',ans)


#Student.display_student_info(s1,"Pune")        #
#Student.display_student_info(s2,"Pune")
print('-'*40)


#implements --> cpython[c] -- webframeworks --> anaconda[c]: data science libs
#
# ---. jython[java] --> pipi[perm] --> ironpython [donnet]

#https://github.com/python/cpython/blob/main/Objects/listobject.c
#s2 = Student(101,'AAAA',20,28934.4) # directly constructor
print(s1.__dict__) # iska meaning -->print the content of s1 in the form of dict-->